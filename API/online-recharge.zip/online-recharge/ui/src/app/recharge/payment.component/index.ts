export { PaymentComponent } from './payment.component';
