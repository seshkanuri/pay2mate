import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'coming-soon',
  templateUrl: './comingsoon.component.html'
})
export class ComingSoonComponent implements OnInit {
  constructor(){}
  ngOnInit(){}
}
