export { ComingSoonComponent } from './comingsoon.component';
