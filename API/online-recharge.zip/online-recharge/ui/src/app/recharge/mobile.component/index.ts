export { MobileComponent } from './mobile.component';
