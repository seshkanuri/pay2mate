import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'feedback',
  templateUrl: './feedback.component.html'
})
export class FeedbackComponent implements OnInit{
  constructor(){}
  ngOnInit(){}
}
