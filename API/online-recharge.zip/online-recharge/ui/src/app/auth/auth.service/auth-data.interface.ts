export interface AuthData {
  id: number;
  name: string;
  email?: string;
  mobile?: number;
  jwt: string;
}
