export { UserProfileComponent } from './user-profile.component';
