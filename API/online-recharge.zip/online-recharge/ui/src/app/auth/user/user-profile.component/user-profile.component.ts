import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-profile',
  templateUrl: 'user-profile.component.pug'
})
export class UserProfileComponent implements OnInit {
    constructor(){}
    ngOnInit(){}
}
